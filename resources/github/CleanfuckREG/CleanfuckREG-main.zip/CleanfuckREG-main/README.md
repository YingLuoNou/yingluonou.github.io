# 简介
用于你手动删除了一个流氓软件后清理烦人的残留的注册表（如无效的打开方式）  
<img height="500" alt="image" src="https://github.com/user-attachments/assets/5d87de39-959c-4702-8faa-f5f8e2ef2117" />

## 用法
1. 在开始菜单（图标）右键点击终端管理员  
2. 克隆本仓库并在刚刚打开终端打开本仓库目录
3. `./fuckclear.ps1`
4. 输入要清理的程序名(例如,某度云盘的智能看图:BaiduNetdiskImageViewer.exe;某W\*S的W\*S图片:photolaunch.exe)
5. 回车，等待清理完成

  另，如有误删请在目录内找到backup文件夹进行还原
